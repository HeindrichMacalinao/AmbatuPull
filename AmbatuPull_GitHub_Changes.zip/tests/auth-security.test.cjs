'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { randomToken, hashToken, createSessionToken, verifySessionToken } = require('../src/lib/auth-security.cjs');
const oldSecret = process.env.SESSION_SECRET;
process.env.SESSION_SECRET = 'test-only-session-secret-that-is-long-enough-and-random-looking';

test('reset/verification token generation is 256-bit and SHA-256 hash is deterministic', () => {
  const a = randomToken(); const b = randomToken();
  assert.match(a, /^[0-9a-f]{64}$/);
  assert.notEqual(a, b);
  assert.equal(hashToken(a).length, 64);
  assert.equal(hashToken(a), hashToken(a));
  assert.notEqual(hashToken(a), hashToken(b));
});
test('signed session is accepted only for valid user and within 24h', () => {
  const now = Date.UTC(2026,10,12,12);
  const session = createSessionToken({ userId: 42 }, now);
  assert.deepEqual(verifySessionToken(session, now + 1000), { userId: 42, issuedAt: now });
  assert.equal(verifySessionToken(session, now + 86401000), null);
});
test('session alteration, forged unsigned token, and wrong signature are rejected', () => {
  const session = createSessionToken({ userId: 1 });
  const [payload, sig] = session.split('.');
  const altered = Buffer.from(JSON.stringify({ userId: 999, iat: 1, exp: 9999999999 })).toString('base64url');
  assert.equal(verifySessionToken(`${altered}.${sig}`), null);
  assert.equal(verifySessionToken(payload), null);
  assert.equal(verifySessionToken(`${payload}.${'x'.repeat(sig.length)}`), null);
});
test('missing/weak secret is rejected', () => {
  const before = process.env.SESSION_SECRET;
  process.env.SESSION_SECRET = 'short';
  assert.throws(() => createSessionToken({ userId: 5 }), /SESSION_SECRET/);
  process.env.SESSION_SECRET = before;
});
process.on('exit', () => { if (oldSecret === undefined) delete process.env.SESSION_SECRET; else process.env.SESSION_SECRET = oldSecret; });
