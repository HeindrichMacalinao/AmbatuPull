'use strict';
/** Execute the actual TypeScript ERP recovery functions against disposable SQLite.
 *  External SMTP/Supabase/bcrypt services are replaced with test-only stubs.
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const { hashToken } = require('../src/lib/auth-security.cjs');

function loadModule(overrides) {
  const filename = path.resolve(__dirname, '../src/lib/erp-db.ts');
  const output = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
    fileName: filename,
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
  }).outputText;
  const compiled = new Module(filename, module);
  compiled.filename = filename;
  compiled.paths = module.paths;
  const nativeRequire = compiled.require.bind(compiled);
  compiled.require = id => Object.hasOwn(overrides, id) ? overrides[id] : nativeRequire(id);
  compiled._compile(output, filename);
  return compiled.exports;
}

test('end-to-end local registration -> verification -> reset -> replay rejection', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ambatu-auth-'));
  const cwd = process.cwd();
  const env = { NODE_ENV: process.env.NODE_ENV, NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY, VERCEL: process.env.VERCEL, ALLOW_DEMO_USERS: process.env.ALLOW_DEMO_USERS };
  const sent = [];
  try {
    process.chdir(dir);
    process.env.NODE_ENV = 'test';
    for (const name of ['NEXT_PUBLIC_SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'VERCEL', 'ALLOW_DEMO_USERS'])
      delete process.env[name];
    const auth = loadModule({
      bcryptjs: {
        hash: async input => `TEST_ONLY_HASH(${input})`,
        hashSync: input => `TEST_ONLY_HASH(${input})`,
      },
      '@/lib/supabase/admin': { getAdminClient: () => { throw Error('Unexpected cloud DB access'); } },
      '@/lib/email': {
        assertEmailDeliveryConfigured() {},
        publicAppUrl: () => 'http://localhost:3000',
        sendVerificationEmail: async item => sent.push({ kind: 'verify', ...item }),
        sendPasswordResetEmail: async item => sent.push({ kind: 'reset', ...item }),
      },
      '@/lib/auth-security.cjs': require('../src/lib/auth-security.cjs'),
    });
    const email = 'new.employee@example.invalid';
    const created = await auth.createUser({ firstName: 'New', lastName: 'Employee', email, password: 'OriginalPassword!2026' });
    assert.equal(created.role, 'User');
    assert.equal((await auth.getUserByEmail(email)).emailVerifiedAt, null);

    await auth.requestEmailVerification(email);
    assert.equal(sent.length, 1);
    const token = new URL(sent[0].verificationLink).searchParams.get('token');
    assert.match(token, /^[0-9a-f]{64}$/);
    const db = auth.getSqliteDb();
    const stored = db.prepare('SELECT * FROM email_verification_token WHERE userId=?').get(created.userId);
    assert.equal(stored.tokenHash, hashToken(token));
    assert.notEqual(stored.tokenHash, token);
    await auth.completeEmailVerification(token);
    assert.ok((await auth.getUserByEmail(email)).emailVerifiedAt);
    await assert.rejects(auth.completeEmailVerification(token), /already used token/);

    await auth.requestPasswordReset(email);
    assert.equal(sent.length, 2);
    const reset = new URL(sent[1].resetLink).searchParams.get('token');
    assert.match(reset, /^[0-9a-f]{64}$/);
    const resetStored = db.prepare('SELECT * FROM password_reset_token WHERE userId=?').get(created.userId);
    assert.equal(resetStored.tokenHash, hashToken(reset));
    assert.notEqual(resetStored.tokenHash, reset);
    assert.equal(await auth.completePasswordReset(reset, 'UpdatedPassword!2026'), true);
    const updated = await auth.getUserByEmail(email);
    assert.equal(updated.passwordHash, 'TEST_ONLY_HASH(UpdatedPassword!2026)');
    assert.ok(db.prepare('SELECT sessionRevokedAt FROM app_user WHERE userId=?').get(created.userId).sessionRevokedAt);
    assert.equal(db.prepare('SELECT isUsed FROM password_reset_token WHERE tokenHash=?').get(hashToken(reset)).isUsed, 1);
    await assert.rejects(auth.completePasswordReset(reset, 'ReplayPassword!2026'), /already used token/);
    assert.equal((await auth.getUserByEmail(email)).passwordHash, 'TEST_ONLY_HASH(UpdatedPassword!2026)');

    db.prepare('UPDATE password_reset_token SET createdAt=? WHERE userId=?').run('2020-01-01 00:00:00', created.userId);
    await auth.requestPasswordReset(email);
    const expiringToken = new URL(sent[2].resetLink).searchParams.get('token');
    db.prepare('UPDATE password_reset_token SET expiresAt=? WHERE tokenHash=?').run('2000-01-01 00:00:00', hashToken(expiringToken));
    await assert.rejects(auth.completePasswordReset(expiringToken, 'ExpiredPassword!2026'), /already used token/);
    assert.equal((await auth.getUserByEmail(email)).passwordHash, 'TEST_ONLY_HASH(UpdatedPassword!2026)');
  } finally {
    process.chdir(cwd);
    for (const [key, value] of Object.entries(env)) {
      if (value === undefined) delete process.env[key]; else process.env[key] = value;
    }
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
