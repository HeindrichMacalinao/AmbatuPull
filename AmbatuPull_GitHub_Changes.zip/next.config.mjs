/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async headers() {
    const sensitiveHeaders = [
      { key: 'Referrer-Policy', value: 'no-referrer' },
      { key: 'Cache-Control', value: 'no-store' },
    ];
    return [
      { source: '/reset-password', headers: sensitiveHeaders },
      { source: '/verify-email', headers: sensitiveHeaders },
    ];
  },
};

export default nextConfig;
