import { NextResponse } from 'next/server';
import { completeEmailVerification, requestEmailVerification } from '@/lib/erp-db';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (typeof body.token === 'string') {
      await completeEmailVerification(body.token);
      return NextResponse.json({ message: 'Email verified. You may now sign in.' });
    }
    if (typeof body.email !== 'string' || body.email.length > 254 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email.trim())) {
      return NextResponse.json({ error: 'Enter a valid email address' }, { status: 400 });
    }
    await requestEmailVerification(body.email.trim().toLowerCase());
    return NextResponse.json({ message: 'If an unverified account exists, we will email a verification link.' }, { status: 202 });
  } catch (err: any) {
    if (err.status === 400) return NextResponse.json({ error: 'Invalid or expired verification link' }, { status: 400 });
    console.error('[auth] Verification unavailable:', err instanceof Error ? err.message : 'unknown');
    return NextResponse.json({ error: 'Email verification is temporarily unavailable' }, { status: 503 });
  }
}
