import { NextResponse } from 'next/server';
import { requestPasswordReset } from '@/lib/erp-db';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (typeof body.email !== 'string' || body.email.length > 254 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email.trim())) {
      return NextResponse.json({ error: 'Enter a valid email address' }, { status: 400 });
    }
    await requestPasswordReset(body.email.trim().toLowerCase());
    // Never disclose the account's existence or return a raw recovery token.
    return NextResponse.json({
      message: 'If the address belongs to an account, recovery instructions will be emailed.',
    }, { status: 202 });
  } catch (err: any) {
    console.error('[auth] Recovery delivery unavailable:', err instanceof Error ? err.message : 'unknown');
    return NextResponse.json({ error: 'Password recovery is temporarily unavailable' }, { status: 503 });
  }
}
