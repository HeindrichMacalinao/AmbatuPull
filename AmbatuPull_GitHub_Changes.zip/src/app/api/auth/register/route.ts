import { NextResponse } from 'next/server';
import { createUser, requestEmailVerification } from '@/lib/erp-db';
import { assertEmailDeliveryConfigured, publicAppUrl } from '@/lib/email';

const EMAIL_REGEX = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { firstName, lastName, email, password, confirmPassword } = body;

    // 1. Validation
    if (typeof firstName !== 'string' || typeof lastName !== 'string' ||
        !firstName.trim() || !lastName.trim() || firstName.trim().length > 50 ||
        lastName.trim().length > 50 || typeof email !== 'string' || email.length > 100 ||
        typeof password !== 'string' || typeof confirmPassword !== 'string' ||
        !password || !confirmPassword) {
      return NextResponse.json(
        { error: 'All fields are required (First Name, Last Name, Email, Password, Confirm Password)' },
        { status: 400 }
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    if (!EMAIL_REGEX.test(cleanEmail)) {
      return NextResponse.json(
        { error: 'Invalid email address format' },
        { status: 400 }
      );
    }

    if (typeof password !== 'string' || password.length < 8 || password.length > 72) {
      return NextResponse.json(
        { error: 'Password must be 8 to 72 characters long' },
        { status: 400 }
      );
    }

    if (password !== confirmPassword) {
      return NextResponse.json(
        { error: 'Password and Confirm Password do not match' },
        { status: 400 }
      );
    }

    // Fail before creating accounts if verification messages cannot be delivered.
    assertEmailDeliveryConfigured();
    publicAppUrl();

    // 2. Create user (forced to 'User' role per Student Guide §1.2 & §3.1)
    const newUser = await createUser({
      firstName,
      lastName,
      email: cleanEmail,
      password,
      role: 'User',
      actor: 'self',
    });

    let emailSent = true;
    try {
      await requestEmailVerification(cleanEmail);
    } catch (error) {
      emailSent = false;
      console.error('[auth] Unable to send registration verification email');
    }
    return NextResponse.json({
      message: emailSent
        ? 'Account created. Check your email for a verification link before signing in.'
        : 'Account created, but email delivery failed. Use Resend Verification when email service is available.',
      emailSent,
      user: newUser,
    }, { status: 201 });
  } catch (err: any) {
    if (err.status === 409 || err.message?.includes('already registered')) {
      return NextResponse.json(
        { error: 'An account with this email address is already registered.' },
        { status: 409 }
      );
    }
    console.error('[API /api/auth/register] error:', err);
    return NextResponse.json(
      { error: 'Registration is temporarily unavailable' },
      { status: err.status || 503 }
    );
  }
}
