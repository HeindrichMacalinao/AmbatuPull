import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { getUserByEmail } from '@/lib/erp-db';
import { createSessionToken } from '@/lib/auth-security.cjs';

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    if (typeof email !== 'string' || !email || typeof password !== 'string' || !password) {
      return NextResponse.json(
        { error: 'Corporate email and password are required' },
        { status: 400 }
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const user = await getUserByEmail(cleanEmail);

    if (!user) {
      return NextResponse.json(
        { error: 'Invalid corporate email or password' },
        { status: 401 }
      );
    }

    // Verify credentials before disclosing account status.
    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) {
      return NextResponse.json(
        { error: 'Invalid corporate email or password' },
        { status: 401 }
      );
    }
    if (user.isBlocked) {
      return NextResponse.json(
        { error: 'Your account has been blocked. Please contact a system administrator.' },
        { status: 403 }
      );
    }
    if (user.status !== 'Active') {
      return NextResponse.json(
        { error: 'Your account is inactive. Please contact system support.' },
        { status: 403 }
      );
    }

    if (!user.emailVerifiedAt) {
      return NextResponse.json({ error: 'Please verify your email address before signing in.' }, { status: 403 });
    }

    const { passwordHash, emailVerifiedAt, sessionRevokedAt, ...userProfile } = user;
    const sessionToken = createSessionToken(userProfile);

    const response = NextResponse.json({
      message: 'Authentication successful',
      user: userProfile,
    });

    // Set HTTP-only cookie for session persistence
    response.cookies.set('erp_session', sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24, // 24 hours; signed token also expires
    });

    return response;
  } catch (err: any) {
    console.error('[API /api/auth/login] error:', err);
    return NextResponse.json(
      { error: 'Authentication service is temporarily unavailable' },
      { status: 500 }
    );
  }
}
