import { NextResponse } from 'next/server';
import { completePasswordReset } from '@/lib/erp-db';

export async function POST(request: Request) {
  try {
    const { token, password, confirmPassword } = await request.json();
    if (typeof token !== 'string' || !/^[a-f0-9]{64}$/.test(token)) {
      return NextResponse.json({ error: 'Invalid or expired password reset link' }, { status: 400 });
    }
    if (typeof password !== 'string' || password.length < 8 || password.length > 72) {
      return NextResponse.json({ error: 'Password must be 8 to 72 characters long' }, { status: 400 });
    }
    if (typeof confirmPassword !== 'string' || password !== confirmPassword) {
      return NextResponse.json({ error: 'Passwords do not match' }, { status: 400 });
    }
    await completePasswordReset(token, password);
    return NextResponse.json({ message: 'Password updated. Please sign in using the new password.' });
  } catch (err: any) {
    if (err.status === 400) {
      return NextResponse.json({ error: 'Invalid or expired password reset link' }, { status: 400 });
    }
    console.error('[auth] Password reset unavailable:', err instanceof Error ? err.message : 'unknown');
    return NextResponse.json({ error: 'Password reset is temporarily unavailable' }, { status: 503 });
  }
}
