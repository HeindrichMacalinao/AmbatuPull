import { NextResponse } from 'next/server';
import { getDashboardMetrics } from '@/lib/erp-db';
import { authenticatedUser } from '@/lib/api-auth';

export async function GET(request: Request) {
  try {
    const actor = await authenticatedUser(request);
    if (!actor) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const metrics = await getDashboardMetrics();
    return NextResponse.json(metrics);
  } catch (err: any) {
    console.error('[API GET /api/dashboard/metrics] error:', err);
    return NextResponse.json(
      { error: err.message || 'Failed to fetch dashboard metrics' },
      { status: 500 }
    );
  }
}
