import { NextResponse } from 'next/server';
import { toggleUserBlock, getUserById } from '@/lib/erp-db';
import { authenticatedUser } from '@/lib/api-auth';

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const actor = await authenticatedUser(request, ['Admin', 'Superadmin']);
    if (!actor) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { id } = await params;
    const userId = Number(id);
    const { isBlocked } = await request.json();

    if (isNaN(userId)) {
      return NextResponse.json({ error: 'Invalid user ID parameter' }, { status: 400 });
    }

    const target = await getUserById(userId);
    if (!target) return NextResponse.json({ error: 'User not found' }, { status: 404 });
    if (userId === actor.userId ||
        (actor.role !== 'Superadmin' && target.role !== 'User')) {
      return NextResponse.json({ error: 'Not permitted to modify this account' }, { status: 403 });
    }
    const updatedUser = await toggleUserBlock(userId, Boolean(isBlocked), actor.email);

    return NextResponse.json({
      message: `User ${isBlocked ? 'blocked' : 'unblocked'} successfully`,
      user: updatedUser,
    });
  } catch (err: any) {
    console.error('[API POST /api/users/:id/block] error:', err);
    return NextResponse.json(
      { error: err.message || 'Block/Unblock operation failed' },
      { status: err.status || 500 }
    );
  }
}
