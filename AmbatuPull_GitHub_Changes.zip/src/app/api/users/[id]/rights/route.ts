import { NextResponse } from 'next/server';
import { ALL_36_RIGHTS, getUserGrantedRights, setUserRights, getUserById } from '@/lib/erp-db';
import { authenticatedUser } from '@/lib/api-auth';

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const actor = await authenticatedUser(_request, ['Admin', 'Superadmin']);
    if (!actor) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { id } = await params;
    const userId = Number(id);

    if (isNaN(userId)) {
      return NextResponse.json({ error: 'Invalid user ID' }, { status: 400 });
    }

    const grantedRights = await getUserGrantedRights(userId);

    return NextResponse.json({
      userId,
      allRights: ALL_36_RIGHTS,
      grantedRights,
    });
  } catch (err: any) {
    console.error('[API GET /api/users/:id/rights] error:', err);
    return NextResponse.json(
      { error: err.message || 'Failed to retrieve rights' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const actor = await authenticatedUser(request, ['Admin', 'Superadmin']);
    if (!actor) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { id } = await params;
    const userId = Number(id);
    const { rights } = await request.json();

    if (isNaN(userId)) {
      return NextResponse.json({ error: 'Invalid user ID' }, { status: 400 });
    }

    if (!Array.isArray(rights)) {
      return NextResponse.json({ error: 'Rights must be an array of right codes' }, { status: 400 });
    }

    const target = await getUserById(userId);
    if (!target) return NextResponse.json({ error: 'User not found' }, { status: 404 });
    if (actor.role !== 'Superadmin' && target.role !== 'User') {
      return NextResponse.json({ error: 'Not permitted to change these rights' }, { status: 403 });
    }
    const savedRights = await setUserRights(userId, rights, actor.email);

    return NextResponse.json({
      message: 'User permissions updated successfully',
      userId,
      grantedRights: savedRights,
    });
  } catch (err: any) {
    console.error('[API POST /api/users/:id/rights] error:', err);
    return NextResponse.json(
      { error: err.message || 'Failed to update user rights' },
      { status: err.status || 500 }
    );
  }
}
