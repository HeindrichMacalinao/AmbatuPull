'use client';

import React, { Suspense, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { CheckCircle2, Mail, AlertCircle } from 'lucide-react';

function VerifyEmailForm() {
  const params = useSearchParams();
  const invoked = useRef(false);
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (invoked.current) return;
    const token = params.get('token');
    if (!token) return;
    invoked.current = true;
    window.history.replaceState(null, '', '/verify-email');
    setLoading(true);
    fetch('/api/auth/verify-email', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    }).then(async res => {
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Verification failed');
      setStatus(data.message);
    }).catch((err: Error) => setError(err.message))
      .finally(() => setLoading(false));
  }, [params]);

  async function resend(event: React.FormEvent) {
    event.preventDefault(); setError(''); setStatus(''); setLoading(true);
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Unable to send email');
      setStatus(data.message);
    } catch (err: any) { setError(err.message || 'Unable to send email'); }
    finally { setLoading(false); }
  }

  return (
    <div className="min-h-[calc(100vh-8rem)] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl p-8 space-y-5">
        <Mail className="w-10 h-10 text-blue-600 mx-auto" />
        <h1 className="text-2xl font-bold text-center">Verify Your Email</h1>
        <p className="text-sm text-slate-600 text-center">Check your inbox for your one-time verification link. It expires after 24 hours.</p>
        {loading && <p className="text-blue-700 text-sm">Processing...</p>}
        {status && <p role="status" className="text-green-700 text-sm flex gap-2"><CheckCircle2 size={18} />{status}</p>}
        {error && <p role="alert" className="text-red-700 text-sm flex gap-2"><AlertCircle size={18} />{error}</p>}
        <form onSubmit={resend} className="space-y-3">
          <label htmlFor="verify-email" className="block text-sm font-semibold">Didn't receive the email?</label>
          <input id="verify-email" required type="email" value={email} onChange={e => setEmail(e.target.value)}
            placeholder="name@company.com" className="w-full rounded-lg border p-3 text-sm" />
          <button disabled={loading} type="submit" className="w-full rounded-lg bg-blue-600 text-white p-3 font-semibold disabled:opacity-50">Resend Verification</button>
        </form>
        <Link className="block text-center text-blue-700 text-sm" href="/login">Back to Sign In</Link>
      </div>
    </div>
  );
}
export default function VerifyEmailPage() {
  return <Suspense fallback={<p>Loading...</p>}><VerifyEmailForm /></Suspense>;
}
