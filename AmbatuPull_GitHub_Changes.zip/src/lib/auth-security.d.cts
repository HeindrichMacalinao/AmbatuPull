export function randomToken(): string;
export function hashToken(token: string): string;
export function createSessionToken(user: { userId: number }, now?: number): string;
export function verifySessionToken(token: string, now?: number): { userId: number; issuedAt: number } | null;
