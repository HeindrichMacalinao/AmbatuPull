import nodemailer from 'nodemailer';

type AccountEmail = {
  recipient: string;
  recipientName?: string;
  link: string;
  expiresInMinutes: number;
};

/** No credentials, tokens or links are written to logs, even in development. */
export function assertEmailDeliveryConfigured() {
  const host = process.env.SMTP_HOST?.trim();
  const from = process.env.SMTP_FROM?.trim();
  const user = process.env.SMTP_USER?.trim();
  const password = process.env.SMTP_PASSWORD;
  if (!host || !from || !user || !password) {
    throw new Error('Email delivery is not configured. Set SMTP_HOST, SMTP_USER, SMTP_PASSWORD, and SMTP_FROM.');
  }
  const port = Number(process.env.SMTP_PORT || 587);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid SMTP_PORT');
  return { host, from, port, secure: process.env.SMTP_SECURE === 'true' || port === 465,
    auth: { user, pass: password } };
}

export function publicAppUrl() {
  const input = process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL;
  if (!input) throw new Error('APP_URL must be configured for account emails');
  const url = new URL(input);
  if (url.protocol !== 'https:' && !(process.env.NODE_ENV !== 'production' &&
      url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))) {
    throw new Error('APP_URL must use HTTPS (localhost HTTP permitted in development)');
  }
  if (url.username || url.password || url.search || url.hash) throw new Error('APP_URL is invalid');
  return url.origin;
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c] || c);
}

async function sendAccountEmail({ recipient, recipientName, link, expiresInMinutes }: AccountEmail,
    kind: 'reset' | 'verify') {
  const config = assertEmailDeliveryConfigured();
  const transporter = nodemailer.createTransport({
    host: config.host, port: config.port, secure: config.secure,
    auth: config.auth, connectionTimeout: 10000, greetingTimeout: 10000, socketTimeout: 15000,
  });
  const isReset = kind === 'reset';
  const title = isReset ? 'Reset your Hope ERP password' : 'Verify your Hope ERP email address';
  const instruction = isReset ? 'Choose a new password' : 'Verify your email address';
  const greeting = recipientName ? `Hello ${recipientName},` : 'Hello,';
  try {
    await transporter.sendMail({
      from: config.from, to: recipient, subject: title,
      text: [greeting, '', `${instruction} using this one-time link:`, link,
        `The link expires in ${expiresInMinutes} minutes.`,
        'If you did not request this email, you may ignore it.'].join('\n'),
      html: `<p>${escapeHtml(greeting)}</p><p>${escapeHtml(instruction)} using the link below:</p>` +
        `<p><a href="${escapeHtml(link)}">${escapeHtml(instruction)}</a></p>` +
        `<p>Expires in ${expiresInMinutes} minutes. If you did not request this, ignore this email.</p>`,
    });
  } finally {
    transporter.close();
  }
}

export async function sendPasswordResetEmail({ recipient, recipientName, resetLink, expiresInMinutes }:
  { recipient: string; recipientName?: string; resetLink: string; expiresInMinutes: number }) {
  await sendAccountEmail({ recipient, recipientName, link: resetLink, expiresInMinutes }, 'reset');
  return true;
}

export async function sendVerificationEmail({ recipient, recipientName, verificationLink, expiresInMinutes }:
  { recipient: string; recipientName?: string; verificationLink: string; expiresInMinutes: number }) {
  await sendAccountEmail({ recipient, recipientName, link: verificationLink, expiresInMinutes }, 'verify');
}
