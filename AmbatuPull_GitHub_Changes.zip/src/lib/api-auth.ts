import { getUserById } from '@/lib/erp-db';
import { verifySessionToken } from '@/lib/auth-security.cjs';
import type { RoleName } from '@/types/erp';

/** Verify a signed session AND recheck the current account state in the database. */
export async function authenticatedUser(request: Request, roles?: RoleName[]) {
  const cookie = request.headers.get('cookie')?.split(';').map(s => s.trim())
    .find(s => s.startsWith('erp_session='))?.slice('erp_session='.length);
  if (!cookie) return null;
  const session = verifySessionToken(cookie);
  if (!session) return null;
  const user = await getUserById(session.userId);
  if (!user || user.isBlocked || user.status !== 'Active' || !user.emailVerifiedAt) return null;
  if (user.sessionRevokedAt && session.issuedAt < new Date(user.sessionRevokedAt).getTime()) return null;
  if (roles && !roles.includes(user.role)) return null;
  return user;
}
