# SecDev: Email verification, authentication and password recovery patch

## Confirmed root causes in the supplied 2026-11-12 repository ZIP

- `src/app/api/auth/forgot-password/route.ts` returned recovery tokens to the browser in nonproduction; the UI exposed them. No SMTP meant an unusable reset link or logged bearer token.
- `src/lib/erp-db.ts` ignored Supabase insertion/update errors and fell back to SQLite, which on Vercel is temporary and separate from the production data.
- The password-reset code performed independent updates to password and token state, so a token could be redeemed twice or be marked used without a password update.
- Registration did not verify email ownership; login accepted users with unconfirmed email addresses.
- Login issued an unsigned, editable Base64 session. The users/rights/block API handlers did not verify a trusted session.
- `src/lib/erp-db.ts` and the login page included predictable evaluation account credentials. The quick-fill login UI is removed and automatic local demo seeds are opt-in in development only.

## Changes

1. **Supabase PostgreSQL migration:** `supabase/migrations/20261112_004_email_verification_and_recovery.sql`
   - `app_user.emailVerifiedAt` and `app_user.sessionRevokedAt` are nullable. **Existing accounts remain unverified**, pending actual email ownership confirmation.
   - Email verification token table stores only a 64-character SHA-256 digest with 24-hour expiry.
   - Atomic, one-time `redeem_erp_email_verification` and `redeem_erp_password_reset` functions, callable only using the service-role credentials.
   - RLS enabled for sensitive user and token tables. Existing anon-client queries against `app_user` may need to move to trusted server routes.
   - Unique digest index, per-user lookup indexes, and password-reset session invalidation.
2. **Next.js handlers:** `/api/auth/register`, `/login`, `/verify-email`, `/forgot-password`, `/reset-password`, `/logout`. No raw tokens returned or logged. Generic recovery response and required password confirmation.
3. **Pages:** `/register`, `/login`, `/verify-email`, `/forgot-password`, `/reset-password`. Email links lead to the frontend; one-time bearer token is removed from the address bar after reading.
4. **Authentication:** signed HMAC session cookie with 24-hour expiry, live account status/role checks before accessing user-management API routes. Blocked/unverified accounts cannot authenticate. Password changes revoke previously issued signed sessions.
5. **Local development:** SQLite creates email verification table and adds optional columns to existing app_user database. It is not a substitute for the Supabase PostgreSQL deployment.

## REQUIRED manual setup before deploying

1. Back up Supabase and apply `20261112_004_email_verification_and_recovery.sql` in the **correct project** (SQL Editor or migration tooling). This patch does not apply it for you.
2. Set `NEXT_PUBLIC_SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` (server-side only), `APP_URL` (the actual deployed **HTTPS** app URL), `SESSION_SECRET` (32+ random bytes), and transactional-email SMTP credentials (`SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`) in Vercel. Redeploy after setting variables. Do **not** expose service-role or SMTP secrets as `NEXT_PUBLIC_*` values.
3. Set up a verified SMTP sender/domain and check SPF/DKIM to improve delivery. Without working SMTP, registration and password recovery cannot deliver mail; the API fails explicitly rather than pretending success.
4. **Legacy users:** migration intentionally does not mark any current user as verified. Existing users need the `/verify-email` resend flow to verify ownership. Do not set `emailVerifiedAt` in bulk unless you have independently verified email ownership. Existing browser sessions are invalid because old unsigned tokens are rejected.
5. Clean up any historical demo users / known passwords from **production**, especially those previously created by test or manual seed scripts. Turn off `ALLOW_DEMO_USERS` on deployments.
6. Verify the `app_user` table has the case-sensitive column names shown in the migration (Supabase uses quoted CamelCase in this project).

## Validation run

- `npm run test:secdev-auth` — HMAC signed-session validation plus integration of the actual TypeScript ERP recovery functions with disposable local SQLite and SMTP/bcrypt test stubs. Tested verified / replayed / expired tokens and password-change revocation.
- `npm test` — existing SQLite/contract tests, including ERP database integrity and legacy reset-token schema.
- `node --check src/lib/auth-security.cjs`
- `npm run test:secdev-auth` — five tests passed in a disposable environment (including app function integration); see `SECDEV_VERIFICATION_RESULTS.txt` in patch.
- The Next.js production build and Supabase/Postgres remote integration **cannot** be confirmed without npm packages and access to the deployed Supabase/Vercel services. Run `npm ci && npm run build` and the manual flow below in a connected environment.

## Manual acceptance test (staging first)

1. Create a new account with an email inbox under your control. Ensure the UI says **verify email** and login rejects the correct password before verification.
2. Follow the verification link, confirm successful activation and a working login. Reuse the link and confirm it is rejected.
3. Request a password reset; the response must be generic and no raw token must appear in JSON, console output, or website UI. Open the received email link, set a new password, then confirm the old password fails and the new password succeeds.
4. Reuse the reset link, use an expired token, and test two concurrent redemption attempts: at most one can succeed.
5. Tamper with `erp_session`; protected `/api/users` and permission/block endpoints must reject it. Confirm `POST /api/auth/logout` expires the HTTP-only session cookie, and a successful password reset invalidates any preexisting session.
6. Ensure a failed SMTP delivery produces a service error (not a fake success) and missing Supabase credentials do not cause an unrelated SQLite login.

## Residual / follow-up risk

- Shared distributed rate limiting / CAPTCHA is strongly recommended for login, verification resend, and recovery (the current DB cooldown is per account only, not IP-distributed).
- A complete end-to-end production audit should review the **separate Express authentication flow** (`src/services/authService.js`) and migrate all protected data APIs to trusted server-side authorization. Do not use localStorage as an authorization source.
- To invalidate already-issued *new* signed sessions on ordinary logout before natural expiry across multiple devices, introduce a durable server-side session/revocation store. Logout currently clears the browser's HTTP-only cookie; password resets invalidate existing sessions server-side.
- A transaction-safe password-reset function is supplied for the Supabase/Postgres path, but its behavior must be validated against the deployed PostgreSQL schema before merging.
